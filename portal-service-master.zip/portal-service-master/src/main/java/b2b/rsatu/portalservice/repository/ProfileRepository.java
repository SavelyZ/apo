package b2b.rsatu.portalservice.repository;

import b2b.rsatu.portalservice.entity.Profile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfileRepository extends JpaRepository<Profile, Long> {

}
