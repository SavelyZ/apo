package b2b.rsatu.portalservice.dto.profile;

import lombok.Data;

@Data
public class ProfileCreateRequestDto extends ProfileDto {

}
