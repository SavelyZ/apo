package b2b.rsatu.portalservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
